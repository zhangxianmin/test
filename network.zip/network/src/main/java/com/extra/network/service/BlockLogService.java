package com.extra.network.service;

import java.util.List;

import com.extra.network.dao.entity.BlockLog;
import com.extra.network.dao.pojo.vo.BlockLogBaseVO;
import com.extra.network.dao.pojo.vo.BlockLogVO;

/**
 * 阻塞网点Service
 * @author HC
 * @date 2017年10月13日
 * @description
 */
public interface BlockLogService {
	
	/**
	 * 根据网点id获取当前网点阻塞，情况列表
	 * @return
	 */
	List<BlockLogVO> listVO(Integer mid);
	
	/**
	 * 获取指定网点，最近阻塞情况
	 * @param mid 网点id
	 * @return
	 */
	BlockLogBaseVO getByLately(Integer mid);

	void save(BlockLog blockLog);

}
