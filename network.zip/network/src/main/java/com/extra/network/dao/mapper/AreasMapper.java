package com.extra.network.dao.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.extra.network.dao.entity.Areas;

public interface AreasMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Areas record);

    int insertSelective(Areas record);

    Areas selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Areas record);

    int updateByPrimaryKey(Areas record);

    /**
     * 根据城市获取区
     * @param cid
     * @return
     */
	List<Areas> listAreas(String cid);

	Areas getArea(String aid);
}