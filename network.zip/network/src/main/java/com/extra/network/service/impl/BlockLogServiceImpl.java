package com.extra.network.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.extra.network.dao.entity.BlockLog;
import com.extra.network.dao.mapper.BlockLogMapper;
import com.extra.network.dao.pojo.vo.BlockLogBaseVO;
import com.extra.network.dao.pojo.vo.BlockLogVO;
import com.extra.network.service.BlockLogService;

@Service
public class BlockLogServiceImpl implements BlockLogService {

	@Autowired
	private BlockLogMapper blockLogMapper;
	
	@Override
	public List<BlockLogVO> listVO(Integer mid) {
		
		return blockLogMapper.listVO(mid);
	}

	@Override
	public BlockLogBaseVO getByLately(Integer mid) {
		
		return blockLogMapper.getByLately(mid);
	}

	@Override
	public void save(BlockLog blockLog) {
		
		blockLogMapper.insertSelective(blockLog);
	}

}
