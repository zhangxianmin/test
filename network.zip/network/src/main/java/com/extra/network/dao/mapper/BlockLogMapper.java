package com.extra.network.dao.mapper;

import java.util.List;

import com.extra.network.dao.entity.BlockLog;
import com.extra.network.dao.pojo.vo.BlockLogBaseVO;
import com.extra.network.dao.pojo.vo.BlockLogVO;

public interface BlockLogMapper {
    int deleteByPrimaryKey(String id);

    int insert(BlockLog record);

    int insertSelective(BlockLog record);

    BlockLog selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(BlockLog record);

    int updateByPrimaryKey(BlockLog record);

    /**
     * 获取某网点下的
     * @param mid
     * @return
     */
	List<BlockLogVO> listVO(Integer mid);

	/**
	 * 获取某网点下的最近的阻塞情况
	 * @param mid
	 * @return
	 */
	BlockLogBaseVO getByLately(Integer mid);
}