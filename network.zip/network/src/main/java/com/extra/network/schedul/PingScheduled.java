package com.extra.network.schedul;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.extra.network.commons.constants.DateTypeConstant;
import com.extra.network.commons.constants.MonitorConstant;
import com.extra.network.commons.constants.PingConstant;
import com.extra.network.commons.uitls.DateUtil;
import com.extra.network.commons.uitls.PingUtil;
import com.extra.network.dao.entity.BlockLog;
import com.extra.network.dao.entity.Monitor;
import com.extra.network.dao.pojo.vo.BlockLogBaseVO;
import com.extra.network.service.BlockLogService;
import com.extra.network.service.MonitorService;

/**
 * 定时任务调度类
 * @author HC
 * @date 2017年10月13日
 * @description
 */
@Component
@Transactional
public class PingScheduled {
	
	private static Logger logger = Logger.getLogger(PingScheduled.class);
	
	@Autowired
	private MonitorService monitorService;
	
	@Autowired
	private BlockLogService blockLogService;
	
	@Scheduled(fixedDelay=3600*5)
	public void reportAndDeal(){
		List<Monitor> list = monitorService.list();

		for(Monitor monitor: list){
			
			Integer mid = monitor.getId();
			//网点地址
			String ipAddress = monitor.getNetworkAddress();
		
			logger.info(String.format("开始ping网点：[%s]", ipAddress));
			
			//判断此网点,是否是阻塞
			if(monitor.getNetworkState()==MonitorConstant.NET_ADDRESS_STATE_CHOKE){
				
				logger.info(String.format("网点：[%s],阻塞", ipAddress));
				//获取阻塞日志中最近的一条数据
				BlockLogBaseVO  blockLogBaseVO = blockLogService.getByLately(mid);
				//获取两时间间隔(小时)
				int times = DateUtil.dateBetween(blockLogBaseVO.getBlockDate(),
						new Date(),DateTypeConstant.HOURS);
				if(times>0){	
					pingAndChangeState(ipAddress,mid,monitor);
				}
				
			}else if(monitor.getNetworkState()==MonitorConstant.NET_ADDRESS_STATE_OK){
				
				pingAndChangeState(ipAddress,mid,monitor);
			}
				
		}
	}
	
	/**
	 * 处理网点
	 * @param ipAddress 网点地址
	 * @param mid 网点id
	 */
	@Transactional
	private void pingAndChangeState(String ipAddress,Integer mid,Monitor monitor){
		Monitor mo = new Monitor();
		mo.setId(mid);
		if(!PingUtil.ping(ipAddress, PingConstant.PINGTIMES,
				PingConstant.TIMEOUT)){
			//发送短信通知
						
			//更改状态
			mo.setNetworkState(MonitorConstant.NET_ADDRESS_STATE_CHOKE);
			//记录进阻塞日志
			BlockLog blockLog = new BlockLog();
			blockLog.setId(UUID.randomUUID().toString());
			blockLog.setMonitorId(mid);
			blockLog.setProvince(monitor.getProvince());
			blockLog.setCity(monitor.getCity());
			blockLog.setRegion(monitor.getRegion());
			blockLog.setDepartment(monitor.getDepartment());
			blockLog.setNetworkAddress(monitor.getNetworkAddress());
			blockLog.setBlockDate(new Date());
			blockLogService.save(blockLog);
		}else{
			
			mo.setNetworkState(MonitorConstant.NET_ADDRESS_STATE_OK);
		}
		monitorService.update(mo);
	}

}
