package com.extra.network.service;

import com.extra.network.dao.pojo.dto.MonitorDTO;

/**
 * 网点服务类
 * @author HC
 * @date 2017年10月10日
 * @description
 */
public interface BranchService {

	/**
	 * 存储网点
	 * @param monitorDTO
	 * @return
	 */
	Integer save(MonitorDTO monitorDTO);

	/**
	 * 网点更新
	 * @param monitorDTO
	 * @return
	 */
	Integer update(MonitorDTO monitorDTO);
}
