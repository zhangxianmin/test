package com.extra.network.dao.pojo.vo;

import java.io.Serializable;
import java.util.Date;

/**
 * 网点阻塞传输类
 * @author HC
 * @date 2017年10月13日
 * @description
 */
public class BlockLogVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String id;
	private Integer monitorId;
	private String area;
	private String department;
	private Date blockDate;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Integer getMonitorId() {
		return monitorId;
	}
	public void setMonitorId(Integer monitorId) {
		this.monitorId = monitorId;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public Date getBlockDate() {
		return blockDate;
	}
	public void setBlockDate(Date blockDate) {
		this.blockDate = blockDate;
	}
	@Override
	public String toString() {
		return "BlockLogVO [id=" + id + ", monitorId=" + monitorId + ", area=" + area + ", blockDate=" + blockDate
				+ "]";
	}
	
}
