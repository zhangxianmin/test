package com.extra.network.dao.pojo;

import java.io.Serializable;

/**
 * 搜索模型
 * @author hc
 * @date 2017年10月18日
 * @description
 */
public class SearchModel implements Serializable{

	private static final long serialVersionUID = 2296063448914493189L;
	
	private String proSeach; //省
	private String citySearch; //市
	private String departSearch; //部门
	private String netAddrSearch; //网点
	
	public String getProSeach() {
		return proSeach;
	}
	public void setProSeach(String proSeach) {
		this.proSeach = proSeach;
	}
	public String getCitySearch() {
		return citySearch;
	}
	public void setCitySearch(String citySearch) {
		this.citySearch = citySearch;
	}
	public String getDepartSearch() {
		return departSearch;
	}
	public void setDepartSearch(String departSearch) {
		this.departSearch = departSearch;
	}
	public String getNetAddrSearch() {
		return netAddrSearch;
	}
	public void setNetAddrSearch(String netAddrSearch) {
		this.netAddrSearch = netAddrSearch;
	}
	@Override
	public String toString() {
		return "SearchModel [proSeach=" + proSeach + ", citySearch=" + citySearch + ", departSearch=" + departSearch
				+ ", netAddrSearch=" + netAddrSearch + "]";
	}

}
