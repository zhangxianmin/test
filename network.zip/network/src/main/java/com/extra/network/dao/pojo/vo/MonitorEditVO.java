package com.extra.network.dao.pojo.vo;

import java.io.Serializable;
import java.util.List;

import com.extra.network.dao.entity.Areas;
import com.extra.network.dao.entity.Cities;

/**
 * 网点编辑VO
 * @author HC
 * @date 2017年10月16日
 * @description
 */
public class MonitorEditVO implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private Integer id;
	private String department;
	private String provinceId;
	private String cityId;
	private List<Cities> cities;  //绑定的城市列表
	private String regionId;     //绑定的区域ID
	private List<Areas> regions; //区域列表
	private String networkAddress; //网点
	private Integer networkState; //网点状态1:通 ; 2:不通
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getProvinceId() {
		return provinceId;
	}
	public void setProvinceId(String provinceId) {
		this.provinceId = provinceId;
	}
	public String getCityId() {
		return cityId;
	}
	public void setCityId(String cityId) {
		this.cityId = cityId;
	}
	public List<Cities> getCities() {
		return cities;
	}
	public void setCities(List<Cities> cities) {
		this.cities = cities;
	}
	public String getRegionId() {
		return regionId;
	}
	public void setRegionId(String regionId) {
		this.regionId = regionId;
	}
	public List<Areas> getRegions() {
		return regions;
	}
	public void setRegions(List<Areas> regions) {
		this.regions = regions;
	}
	public String getNetworkAddress() {
		return networkAddress;
	}
	public void setNetworkAddress(String networkAddress) {
		this.networkAddress = networkAddress;
	}
	public Integer getNetworkState() {
		return networkState;
	}
	public void setNetworkState(Integer networkState) {
		this.networkState = networkState;
	}
	@Override
	public String toString() {
		return "MonitorEditVO [id=" + id + ", department=" + department + ", provinceId=" + provinceId + ", cityId="
				+ cityId + ", cities=" + cities + ", regionId=" + regionId + ", regions=" + regions
				+ ", networkAddress=" + networkAddress + ", networkState=" + networkState + "]";
	}
	
}
