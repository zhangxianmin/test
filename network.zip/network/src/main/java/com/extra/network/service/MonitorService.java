package com.extra.network.service;

import java.util.List;

import com.extra.network.dao.entity.Monitor;
import com.extra.network.dao.pojo.SearchModel;
import com.extra.network.dao.pojo.vo.MonitorEditVO;
import com.extra.network.dao.pojo.vo.MonitorVO;

public interface MonitorService {

	List<MonitorVO> listMonitor();
	
	Monitor getMonitor(Integer id);

	Integer update(Monitor monitor);

	/**
	 * 获取绑定列表
	 * @return 原生entity
	 */
	List<Monitor> list();

	/**
	 * 获取绑定
	 * @param mid
	 * @return
	 */
	MonitorEditVO find(Integer mid);

	/**
	 * 获取搜索列表
	 * @param searchModel
	 * @return
	 */
	List<MonitorVO> SearchMonitor(SearchModel searchModel);
}
