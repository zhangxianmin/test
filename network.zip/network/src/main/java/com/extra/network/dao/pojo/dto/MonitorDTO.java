package com.extra.network.dao.pojo.dto;

import java.io.Serializable;

/**
 * 添加网点DTO
 * @author HC
 * @date 2017年10月10日
 * @description
 */
public class MonitorDTO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private Integer id;
	private String provinceId;
	private String cityId;
	private String regionId;
	private String department;
	private String networkAddress;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getProvinceId() {
		return provinceId;
	}
	public void setProvinceId(String provinceId) {
		this.provinceId = provinceId;
	}
	public String getCityId() {
		return cityId;
	}
	public void setCityId(String cityId) {
		this.cityId = cityId;
	}
	public String getRegionId() {
		return regionId;
	}
	public void setRegionId(String regionId) {
		this.regionId = regionId;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getNetworkAddress() {
		return networkAddress;
	}
	public void setNetworkAddress(String networkAddress) {
		this.networkAddress = networkAddress;
	}
	@Override
	public String toString() {
		return "MonitorDTO [provinceId=" + provinceId + ", cityId=" + cityId + ", regionId=" + regionId
				+ ", department=" + department + ", networkAddress=" + networkAddress + "]";
	}	

}
