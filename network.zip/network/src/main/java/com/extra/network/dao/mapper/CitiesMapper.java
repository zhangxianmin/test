package com.extra.network.dao.mapper;

import java.util.List;

import com.extra.network.dao.entity.Cities;

public interface CitiesMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Cities record);

    int insertSelective(Cities record);

    Cities selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Cities record);

    int updateByPrimaryKey(Cities record);

    /**
     * 根据省获取城市
     * @param pid
     * @return
     */
	List<Cities> listCities(String pid);

	Cities getCity(String cid);
}