package com.extra.network.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.extra.network.dao.entity.Monitor;
import com.extra.network.dao.mapper.MonitorMapper;
import com.extra.network.dao.pojo.SearchModel;
import com.extra.network.dao.pojo.vo.MonitorEditVO;
import com.extra.network.dao.pojo.vo.MonitorVO;
import com.extra.network.service.AreaService;
import com.extra.network.service.MonitorService;

@Service
public class MonitorServiceImpl implements MonitorService {

	@Autowired
	private MonitorMapper monitorMapper;
	
	@Autowired
	private AreaService areaService;
	
	@Override
	public List<MonitorVO> listMonitor() {
		
		return monitorMapper.list();
	}

	@Override
	public Monitor getMonitor(Integer id) {
		
		return monitorMapper.selectByPrimaryKey(id);
	}

	@Override
	public Integer update(Monitor monitor) {
		
		return monitorMapper.updateByPrimaryKeySelective(monitor);
	}

	@Override
	public List<Monitor> list() {
		
		return monitorMapper.listProto();
	}

	@Override
	public MonitorEditVO find(Integer mid) {
		
		Monitor monitor = monitorMapper.selectByPrimaryKey(mid);
		
		String provinceId = monitor.getProvinceId();
		String cityId = monitor.getCityId();
		String regionId = monitor.getRegionId();
		
		MonitorEditVO monitorEditVO = new MonitorEditVO();
		monitorEditVO.setId(monitor.getId());
		monitorEditVO.setProvinceId(provinceId);
		monitorEditVO.setCityId(cityId);
		monitorEditVO.setRegionId(regionId);
		monitorEditVO.setDepartment(monitor.getDepartment());
		monitorEditVO.setNetworkAddress(monitor.getNetworkAddress());
		monitorEditVO.setNetworkState(monitor.getNetworkState());
		
		monitorEditVO.setCities(areaService.listCities(provinceId));
		monitorEditVO.setRegions(areaService.listAreas(cityId));
		
		return monitorEditVO;
	}

	@Override
	public List<MonitorVO> SearchMonitor(SearchModel searchModel) {
		
		return monitorMapper.SearchMonitor(searchModel);
	}

}
