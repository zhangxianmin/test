package com.extra.network.service;

import java.util.List;

import com.extra.network.dao.entity.Areas;
import com.extra.network.dao.entity.Cities;
import com.extra.network.dao.entity.Provinces;

/**
 * 
 * @author HC
 * @date 2017年10月10日
 * @description
 */
public interface AreaService {
	
	/**
	 * 获取省级列表
	 * @return
	 */
	List<Provinces> ListProvinces();
	
	/**
	 * 根据省级id,获取城市列表
	 * @param pid 省级id
	 * @return
	 */
	List<Cities> listCities(String pid);
	
	/**
	 * 根据城市id,获取区列表
	 * @param cid
	 * @return
	 */
	List<Areas>  listAreas(String cid);
	
	/**
	 * 根据省id获取省名称
	 * @param pid
	 * @return
	 */
	String getProvinces(String pid);
	
	/**
	 * 根据城市id获取城市名
	 * @param cid
	 * @return
	 */
	String getCity(String cid);
	
	/**
	 * 根据区域id获取区域名
	 * @param aid
	 * @return
	 */
	String getArea(String aid);
}
