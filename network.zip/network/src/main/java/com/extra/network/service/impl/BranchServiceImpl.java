package com.extra.network.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.extra.network.commons.constants.MonitorConstant;
import com.extra.network.commons.constants.PingConstant;
import com.extra.network.commons.uitls.PingUtil;
import com.extra.network.dao.entity.Monitor;
import com.extra.network.dao.mapper.MonitorMapper;
import com.extra.network.dao.pojo.dto.MonitorDTO;
import com.extra.network.service.AreaService;
import com.extra.network.service.BranchService;

@Service
public class BranchServiceImpl implements BranchService{

	@Autowired
	private MonitorMapper monitorMapper; 
	
	@Autowired
	private AreaService areaService;
	
	@Override
	public Integer save(MonitorDTO monitorDTO) {
		
		String ipAddress = monitorDTO.getNetworkAddress();
		//基本数据绑定
		Monitor monitor = bindData(monitorDTO,ipAddress);
		
		if(monitor == null){
			return 0;
		}
		
		return monitorMapper.insertSelective(monitor);
	}
	
	@Override
	public Integer update(MonitorDTO monitorDTO) {
		String ipAddress = monitorDTO.getNetworkAddress();
		//基本数据绑定
	    Monitor monitor = bindData(monitorDTO,ipAddress);
	    if(monitor == null){
	    	return 0;
	    }
	    monitor.setId(monitorDTO.getId());
	    
		return monitorMapper.updateByPrimaryKeySelective(monitor);
	}
	
	/**
	 * 数据绑定
	 * @param monitor
	 * @param monitorDTO
	 */
	private Monitor bindData(MonitorDTO monitorDTO,String ipAddress){
		Monitor monitor = null;
		if(PingUtil.ping(ipAddress, PingConstant.PINGTIMES,
				PingConstant.TIMEOUT)){
			
			monitor = new Monitor();
			
			monitor.setDepartment(monitorDTO.getDepartment());
			monitor.setProvinceId(monitorDTO.getProvinceId());
			monitor.setCityId(monitorDTO.getCityId());
			monitor.setRegionId(monitorDTO.getRegionId());
			monitor.setNetworkAddress(ipAddress);
			dealArea(monitor,monitorDTO);
			monitor.setNetworkState(MonitorConstant.NET_ADDRESS_STATE_OK);
			monitor.setState(MonitorConstant.STATE_ENABLE);
		}
		
		return monitor;
	}
	
	/**
	 * 区域处理
	 * @param monitor
	 * @param monitorDTO
	 */
	private void dealArea(Monitor monitor,MonitorDTO monitorDTO){
		String provinceName = areaService.getProvinces(monitorDTO.getProvinceId());
		String cityName = areaService.getCity(monitorDTO.getCityId());
		String areaName = areaService.getArea(monitorDTO.getRegionId());
		monitor.setProvince(provinceName);
		monitor.setCity(cityName);
		monitor.setRegion(areaName);
	}
	

}
