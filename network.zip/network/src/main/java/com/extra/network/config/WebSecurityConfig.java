package com.extra.network.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

/**
 * Spring Security 配置文件
 * @author HC
 * @date 2017年10月9日
 * @description
 */
@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http
			.authorizeRequests()
				.antMatchers("/login","/assets/**").permitAll() //添加允许通过的地址
				.anyRequest().authenticated()
				.and()
			.formLogin() //定义用户需要登录时跳转的页面
				.loginPage("/login")
				.permitAll()
				.and()
			.logout()
				.permitAll();
	}

	/**
	 * 全局定义一个用户
	 * @param auth
	 * @throws Exception
	 * @description 用户名：root ; 密码：admin
	 */
    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
        auth
            .inMemoryAuthentication()
                .withUser("root").password("admin").roles("USER");
    }
}
