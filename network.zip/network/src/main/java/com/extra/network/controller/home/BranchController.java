package com.extra.network.controller.home;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.extra.network.dao.entity.Areas;
import com.extra.network.dao.entity.Cities;
import com.extra.network.dao.pojo.dto.MonitorDTO;
import com.extra.network.dao.pojo.vo.MonitorEditVO;
import com.extra.network.service.AreaService;
import com.extra.network.service.BranchService;
import com.extra.network.service.MonitorService;

/**
 * 网点控制器
 * @author HC
 * @date 2017年10月10日
 * @description
 */
@Controller
@RequestMapping("/branch")
public class BranchController {
	
	@Autowired
	private BranchService branchService;
	
	@Autowired
	private AreaService areaService;
	
	@Autowired
	private MonitorService monitorService;
	
	@GetMapping("/bind")
	public ModelAndView bind(ModelAndView view){
		view.addObject("provinceList", areaService.ListProvinces());
		view.setViewName("form_bind");
		return view;
	}
	/**
	 * 添加网点
	 * @param monitorDTO
	 * @param view
	 * @return
	 */
	@PostMapping("/add")
	@ResponseBody
	public Integer add(@ModelAttribute("monitorDTO") MonitorDTO monitorDTO,RedirectAttributes attr){
		Assert.notNull(monitorDTO.getProvinceId(), "错误操作");
		Assert.notNull(monitorDTO.getNetworkAddress(), "错误操作");
		Assert.notNull(monitorDTO.getDepartment(), "错误操作");	
		
		return branchService.save(monitorDTO);
	}
	
	@PostMapping("/update")
	@ResponseBody
	public Integer update(@ModelAttribute("monitorDTO") MonitorDTO monitorDTO){
		Assert.notNull(monitorDTO.getProvinceId(), "错误操作");
		Assert.notNull(monitorDTO.getNetworkAddress(), "错误操作");
		Assert.notNull(monitorDTO.getDepartment(), "错误操作");
		Assert.notNull(monitorDTO.getId(), "错误操作");
		
		return branchService.update(monitorDTO);
	} 
	/**
	 * ajax处理：获取某省下的城市列表
	 * @param pid 省id
	 * @return
	 */
	@GetMapping("/listCity")
	@ResponseBody
	public List<Cities> findCitys(@RequestParam String pid){
		
		return areaService.listCities(pid);
	}

	/**
	 * ajax处理：获取某城市下的区
	 * @param cid 城市id
	 * @return
	 */
	@GetMapping("/listArea")
	@ResponseBody
	public List<Areas> findAreas(@RequestParam String cid){
		
		return areaService.listAreas(cid);
	}
	
	/**
	 * 获取编辑信息
	 * @param mid
	 * @return
	 */
	@GetMapping("/findedit")
	@ResponseBody
	public MonitorEditVO find(@RequestParam("mid") Integer mid){
		
		return monitorService.find(mid);
	}
	
}
