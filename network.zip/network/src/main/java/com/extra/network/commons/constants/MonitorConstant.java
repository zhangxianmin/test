package com.extra.network.commons.constants;

/**
 * 网点常量
 * @author HC
 * @date 2017年10月13日
 * @description
 */
public interface MonitorConstant {

	/**
	 * 网络状态—畅通
	 */
	Integer NET_ADDRESS_STATE_OK = 1;
	/**
	 * 网络状态-阻塞
	 */
	Integer NET_ADDRESS_STATE_CHOKE = 2;
	/**
	 * 绑定网点状态—启用
	 */
	Integer STATE_ENABLE = 1;
	/**
	 * 绑定网点状态-禁用
	 */
	Integer STATE_DISABLE = 2;
	 
}
