package com.extra.network.commons.constants;
/**
 * 时间单位
 * @author HC
 * @date 2017年10月13日
 * @description
 */
public interface DateTypeConstant {
	
	String SECONDS = "Seconds";
	String MINUTES = "Minutes";
	String HOURS = "Hours";
	String DAYS = "Days";
	String MONTHS = "Months";

}
