package com.extra.network.dao.mapper;

import java.util.List;

import com.extra.network.dao.entity.Monitor;
import com.extra.network.dao.pojo.SearchModel;
import com.extra.network.dao.pojo.vo.MonitorVO;

public interface MonitorMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Monitor record);

    int insertSelective(Monitor record);

    Monitor selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Monitor record);

    int updateByPrimaryKey(Monitor record);
    /**
     * 获取监控列表
     * @return
     */
	List<MonitorVO> list();

	List<Monitor> listProto();

	/**
	 * 获取搜索列表
	 * @param searchModel
	 * @return
	 */
	List<MonitorVO> SearchMonitor(SearchModel searchModel);
}