package com.extra.network.commons.constants;

/**
 * ping常量
 * @author HC
 *
 */
public interface PingConstant {

	Integer PINGTIMES = 3; //ping的次数
	Integer TIMEOUT = 3000; //超时时间
}
