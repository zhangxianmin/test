package com.extra.network.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.extra.network.dao.entity.Areas;
import com.extra.network.dao.entity.Cities;
import com.extra.network.dao.entity.Provinces;
import com.extra.network.dao.mapper.AreasMapper;
import com.extra.network.dao.mapper.CitiesMapper;
import com.extra.network.dao.mapper.ProvincesMapper;
import com.extra.network.service.AreaService;

/**
 * 
 * @author HC
 * @date 2017年10月10日
 * @description
 */
@Service
public class AreaServiceImpl implements AreaService{

	@Autowired
	private ProvincesMapper provincesMapper;
	
	@Autowired
	private CitiesMapper citiesMapper;
	
	@Autowired
	private AreasMapper areasMapper;
	
	@Override
	public List<Provinces> ListProvinces() {
		
		return provincesMapper.list();
	}

	@Override
	public List<Cities> listCities(String pid) {
		
		return citiesMapper.listCities(pid);
	}

	@Override
	public List<Areas> listAreas(String cid) {
		
		return areasMapper.listAreas(cid);
	}

	@Override
	public String getProvinces(String pid) {
		
		return provincesMapper.getProvince(pid).getProvince();
	}

	@Override
	public String getCity(String cid) {
		
		return citiesMapper.getCity(cid).getCity();
	}

	@Override
	public String getArea(String aid) {
		
		return areasMapper.getArea(aid).getArea();
	}
	
	

}
