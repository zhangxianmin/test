package com.extra.network.dao.pojo.vo;

import java.io.Serializable;

public class MonitorVO implements Serializable{

	private static final long serialVersionUID = 1L;
	private Integer id;
	private String department;
	private String area;
	private String networkAddress;
	private Integer networkState;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getNetworkAddress() {
		return networkAddress;
	}
	public void setNetworkAddress(String networkAddress) {
		this.networkAddress = networkAddress;
	}
	public Integer getNetworkState() {
		return networkState;
	}
	public void setNetworkState(Integer networkState) {
		this.networkState = networkState;
	}
	@Override
	public String toString() {
		return "MonitorVO [id=" + id + ", department=" + department + ", area=" + area + ", networkAddress="
				+ networkAddress + ", networkState=" + networkState + "]";
	}
}
