package com.extra.network.dao.pojo.vo;

import java.io.Serializable;
import java.util.Date;

/**
 * 网点阻塞基础
 * @author HC
 * @date 2017年10月13日
 * @description
 */
public class BlockLogBaseVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String id;

    private Integer monitorId;

    private String province;

    private String city;

    private String region;

    private String department;

    private String networkAddress;

    private Date blockDate;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Integer getMonitorId() {
		return monitorId;
	}

	public void setMonitorId(Integer monitorId) {
		this.monitorId = monitorId;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getNetworkAddress() {
		return networkAddress;
	}

	public void setNetworkAddress(String networkAddress) {
		this.networkAddress = networkAddress;
	}

	public Date getBlockDate() {
		return blockDate;
	}

	public void setBlockDate(Date blockDate) {
		this.blockDate = blockDate;
	}

	@Override
	public String toString() {
		return "BlockLogBaseVO [id=" + id + ", monitorId=" + monitorId + ", province=" + province + ", city=" + city
				+ ", region=" + region + ", department=" + department + ", networkAddress=" + networkAddress
				+ ", blockDate=" + blockDate + "]";
	}
    
}
