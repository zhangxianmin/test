package com.extra.network.controller.home;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.extra.network.dao.entity.Monitor;
import com.extra.network.dao.pojo.SearchModel;
import com.extra.network.dao.pojo.vo.MonitorVO;
import com.extra.network.service.AreaService;
import com.extra.network.service.MonitorService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

@Controller
public class HomeController {
	
	@Value("${page.pagesize}")
	private Integer pageSize;
	
	@Autowired
	private MonitorService monitorService;
	
	@Autowired
	private AreaService areaService;
	
	@GetMapping(value={"/","/index"})
	public ModelAndView index(ModelAndView view){
		PageHelper.startPage(0, pageSize);
		List<MonitorVO> monitorList = monitorService.listMonitor();
		PageInfo<MonitorVO> pageInfo = new PageInfo<MonitorVO>(monitorList);
		
		view.addObject("pageInfo", pageInfo);
		view.addObject("provinceList", areaService.ListProvinces());
		view.setViewName("index");
		return view;
	}
	
	/**
	 * 分页处理
	 * @param page 当前页数
	 * @return
	 */
	@GetMapping("/page")
	@ResponseBody
	public List<MonitorVO> page(@RequestParam("page") Integer page){
		PageHelper.startPage(page, pageSize);
		List<MonitorVO> monitorList = monitorService.listMonitor();
		PageInfo<MonitorVO> pageInfo = new PageInfo<MonitorVO>(monitorList);
		
		return pageInfo.getList();
	}
	
	/**
	 * 搜索页面
	 * @param view
	 * @param searchModel 搜索模型
	 * @return
	 */
	@GetMapping("/search")
	public ModelAndView search(ModelAndView view,SearchModel searchModel){
		PageHelper.startPage(0, pageSize);
		List<MonitorVO> monitorList = monitorService.SearchMonitor(searchModel);
		PageInfo<MonitorVO> pageInfo = new PageInfo<MonitorVO>(monitorList);
		
		view.addObject("pageInfo", pageInfo);
		view.addObject("provinceList", areaService.ListProvinces());
		view.setViewName("search");
		
		return view;
	}
	/**
	 * ajax：搜索分页查询
	 * @param searchModel
	 * @param page 页码
	 * @return
	 */
	@GetMapping("/searchPage")
	@ResponseBody
	public List<MonitorVO> searchPage(SearchModel searchModel,@RequestParam Integer page){
		PageHelper.startPage(page, pageSize);
		List<MonitorVO> monitorList = monitorService.SearchMonitor(searchModel);
		PageInfo<MonitorVO> pageInfo = new PageInfo<MonitorVO>(monitorList);
		
		return pageInfo.getList();
	}
	
	/**
	 * ajax处理:逻辑删除网点监控
	 * @param id
	 * @return
	 */
	@GetMapping("/del")
	@ResponseBody
	public Integer del(Integer id){
		Monitor monitor = new Monitor();
		monitor.setId(id);
		monitor.setState(2);
		return monitorService.update(monitor);
	}
	
}
