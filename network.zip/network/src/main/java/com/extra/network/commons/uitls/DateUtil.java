package com.extra.network.commons.uitls;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.Hours;
import org.joda.time.Minutes;
import org.joda.time.Months;
import org.joda.time.Seconds;

import com.extra.network.commons.constants.DateTypeConstant;

/**
 * 时间处理类
 * @author HC
 * @date 2017年10月13日
 * @description
 */
public class DateUtil {
	
	/**
	 * 获取时间间隔
	 * @param time1
	 * @param time2
	 * @return
	 */
	public static int dateBetween(Date time1,Date time2,String type){
		DateTime dt1 = new DateTime(time1);
		DateTime dt2 = new DateTime(time2);
		int times = -1;
		switch (type) {
		
			case DateTypeConstant.SECONDS:
				
				times = Math.abs(Seconds.secondsBetween(dt1, dt2).getSeconds());
				break;
			case DateTypeConstant.MINUTES:
				
				times = Math.abs(Minutes.minutesBetween(dt1, dt2).getMinutes());
				break;
			case DateTypeConstant.HOURS:
				
				times = Math.abs(Hours.hoursBetween(dt1, dt2).getHours());
				break;
			case DateTypeConstant.DAYS:
				
				times = Math.abs(Days.daysBetween(dt1, dt2).getDays());
				break;	
			case DateTypeConstant.MONTHS:
				
				times = Math.abs(Months.monthsBetween(dt1, dt2).getMonths());
				break;
			default:
				break;
		}
		
		return times;
	}

}
