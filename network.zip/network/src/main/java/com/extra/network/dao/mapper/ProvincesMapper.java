package com.extra.network.dao.mapper;

import java.util.List;

import com.extra.network.dao.entity.Provinces;

public interface ProvincesMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Provinces record);

    int insertSelective(Provinces record);

    Provinces selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Provinces record);

    int updateByPrimaryKey(Provinces record);

    /**
     * 获取省级列表
     * @return
     */
	List<Provinces> list();

	Provinces getProvince(String pid);
}