	  $(function(){
		  $("#proSelect").change(function(){
		  var pid = this.value;
		  $.ajax({
			  url:"/network/branch/listCity",
			  method:"GET",
			  data:{
				  pid:pid
			  },
			  success:function(data){
				  var str="";
				  data.forEach(function(currItem){
					  str+="<option value='"+currItem.cityid+"'>"+currItem.city+"</option>";
				  });
				  $("#citySelect")[0].length =1;
				  $("#areaSelect")[0].length =1;
				  $("#citySelect").append(str);	  
			  },
			  error:function(){
				  alert("服务器连接异常");
				  window.location.reload();
			  } 
		  })  
	  });
	  
	  $("#citySelect").change(function(){
		  var cid = this.value;
		  $.ajax({
			  url:"/network/branch/listArea",
			  method:"Get",
			  data:{
				  cid:cid
			  },
			  success:function(data){
				  var str="";
				  data.forEach(function(currItem){
					  str+="<option value='"+currItem.areaid+"'>"+currItem.area+"</option>";
				  });
				  $("#areaSelect")[0].length =1;
				  $("#areaSelect").append(str);
			  },
			  error:function(){
				  alert("服务器连接异常");
				  window.location.reload();
			  }  
		  })
	  }) 
	  
	  $("#editForm").submit(verify);
	  });
	  
	  function verify(){
		  
		  if($("#proSelect").val()=='default'){
			  alert("省不能为空");
			  return false;
		  }
		  if($("#citySelect").val()=='default'){
			  alert("市不能为空");
			  return false;
		  }
		  if($("#areaSelect").val()=='default'){
			  alert("区域不能为空");
				  return false;
			  }
			  return true;
	  }