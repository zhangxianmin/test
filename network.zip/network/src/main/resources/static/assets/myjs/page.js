$(function(){
		
	var pageCount = $("#container").attr("data-pageCount");
	var pageSize = $("#container").attr("data-pageSize");
	
	
      $("[data-toggle='popover']").popover();	
      $('.M-box').pagination({
    	  totalData:pageCount,
    	    showData:pageSize,
    	    callback:function(api){
    	    	var data = {
    	                page: api.getCurrent()
    	            };
    	            $.getJSON("page",data,function(json){
    	                console.log(json);
    	                var listStr = "";
    	                
    	                json.forEach(function(iteam){
    	                	listStr+="<tr><td style='display:none' id='proId'>"+iteam.id+"</td>";
    	                	listStr+="<td style='overflow:hidden;white-space:nowrap ;text-overflow:ellipsis;' data-content='"+iteam.department+"'><a href='javascript:void();'>"+iteam.department+"</a></td>";
    	                	listStr+="<td class='hidden-phone' style='overflow:hidden;white-space:nowrap ;text-overflow:ellipsis;'>"+iteam.area+"</td>";
    	                	listStr+="<td style='overflow:hidden;white-space:nowrap ;text-overflow:ellipsis;'>"+iteam.networkAddress+"</td>";
    	                	if(iteam.networkState == 1){
    	                		listStr+="<td><span class='label label-success label-mini'>正常</span></td>";
    	                	}else{
    	                		listStr+="<td><span class='label label-warning label-mini'>阻塞</span></td>";
    	                	}
    	                	listStr+="<td><button class='btn btn-primary btn-xs' data-toggle='modal' data-target='#editModal' id='edit' data-id='"+iteam.id+"' onclick='getData(event)'><i class='fa fa-pencil'></i></button>   ";
    	                	listStr+="<button class='btn btn-danger btn-xs' data-toggle='modal' data-target='#myModal' data-id='"+iteam.id+"' onclick='getData(event)'><i class='fa fa-trash-o'></i></button></td></tr>";
    	                });
    	                
    	                $("#tbodyContent").html(listStr);    
    	            });
    	    }
    	},function(api){
    	    $('.now').text(api.getCurrent());
      });
});