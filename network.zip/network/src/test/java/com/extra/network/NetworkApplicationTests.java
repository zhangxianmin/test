package com.extra.network;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.extra.network.dao.pojo.vo.MonitorVO;
import com.extra.network.service.BlockLogService;
import com.extra.network.service.MonitorService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class NetworkApplicationTests {
	
	@Autowired
	MonitorService monitorService;
	
	@Autowired
	BlockLogService blockLogService;

	@Test
	public void contextLoads() {
		 List<MonitorVO> list = monitorService.listMonitor();
		 System.out.println(list);
	}
	@Test
	public void hh(){
		System.err.println(monitorService.getMonitor(1));
	}
	
	@Test
	public void testBlockLog(){
		System.out.println(blockLogService.getByLately(1));
	}
	
	@Test
	public void testLog(){
		System.out.println(blockLogService.listVO(1));
	}
}
